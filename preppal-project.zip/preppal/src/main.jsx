import React from 'react'
import ReactDOM from 'react-dom/client'
import PrepPal from './App'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <PrepPal />
  </React.StrictMode>
)
