import { useState, useEffect, useRef, useCallback } from "react";

/* ── Storage: localStorage for real deployment ── */
function sGet(k) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : null; } catch { return null; } }
function sSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }

/* ── Alarm ── */
function playAlarm() { try { const c = new (window.AudioContext || window.webkitAudioContext)(); const b = (f, s, d) => { const o = c.createOscillator(), g = c.createGain(); o.connect(g); g.connect(c.destination); o.type = "sine"; o.frequency.value = f; g.gain.setValueAtTime(0.3, s); g.gain.exponentialRampToValueAtTime(0.01, s + d); o.start(s); o.stop(s + d); }; b(523, c.currentTime, 0.3); b(659, c.currentTime + 0.35, 0.3); b(784, c.currentTime + 0.7, 0.5); } catch {} }

/* ── Claude API ── */
async function ask(sys, text, maxT) {
  const doF = async () => {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: maxT || 1024, system: sys, messages: [{ role: "user", content: text }] })
    });
    const d = await r.json();
    if (d.error) throw new Error(d.error.message);
    return d.content?.filter(b => b.type === "text").map(b => b.text).join("\n") || "No response.";
  };
  return Promise.race([doF(), new Promise((_, j) => setTimeout(() => j(new Error("timeout")), 20000))]);
}

/* ── Constants ── */
const PRICE = "$4.99/mo";
const STRIPE = "https://buy.stripe.com/aFadR82Ne1Lp9fCdbA9R604";
const PRO = ["himc798@gmail.com"];
const TABS = [
  { id: "flash", l: "Flashcards", i: "⚡" },
  { id: "quiz", l: "Quiz Me", i: "🎯" },
  { id: "sum", l: "Summarize", i: "✍️" },
  { id: "hw", l: "HW Helper", i: "📚" },
  { id: "poster", l: "Poster", i: "🎨" },
  { id: "timer", l: "Focus", i: "⏱" },
];

/* ── Themes ── */
const LT = { bg: "#fdfcfb", card: "#fff", bdr: "#e8e3dc", tx: "#1a1a2e", tx2: "#636e72", tx3: "#b2bec3", ac: "#9b7dff", ac2: "#7c5ce0", abg: "#f0ebff", ibg: "#fdfcfb", cbg: "#f5f0ea", ub: "#9b7dff", ut: "#fff", ab: "#fff", at: "#1a1a2e", sb: "#ede8e0" };
const DK = { bg: "#0f0e17", card: "#1e1d2f", bdr: "#2a2945", tx: "#e8e6f0", tx2: "#9896a8", tx3: "#5c5a6e", ac: "#9b7dff", ac2: "#7c5ce0", abg: "rgba(155,125,255,.12)", ibg: "#1a1932", cbg: "#151425", ub: "#9b7dff", ut: "#fff", ab: "#1e1d2f", at: "#e8e6f0", sb: "#12111f" };

const TN = () => new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
const isG = (t, k) => k.some(w => t.toLowerCase().includes(w));
const pil = t => ({ padding: "6px 14px", border: "1.5px solid " + t.bdr, borderRadius: 20, background: "transparent", color: t.tx2, fontSize: 13, fontFamily: "inherit", fontWeight: 500, cursor: "pointer" });
const GREET = { flash: "Hey! 👋 Paste notes and I'll make flashcards.", quiz: "Paste notes and say how many questions! 🧠", sum: "Paste notes! ✍️ Say 'outline','cornell', or 'eli5'.", hw: "Ask me anything! 📚 Step by step.", poster: "Tell me a poster topic! 🎨" };

/* ── Shared Components ── */
function Dots({ t }) {
  return <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "12px 16px", background: t.ab, border: "1px solid " + t.bdr, borderRadius: "16px 16px 16px 4px", maxWidth: "80%", alignSelf: "flex-start" }}>{[0, 1, 2].map(i => <div key={i} style={{ width: 8, height: 8, borderRadius: "50%", background: t.ac, animation: "dp 1.4s ease " + (i * 0.2) + "s infinite" }} />)}<span style={{ fontSize: 13, color: t.tx2, marginLeft: 4 }}>Thinking...</span></div>;
}

function Bub({ m, t }) {
  const u = m.role === "user";
  return <div style={{ display: "flex", flexDirection: "column", alignItems: u ? "flex-end" : "flex-start", animation: "fu .3s ease" }}>{m.time && <span style={{ fontSize: 10, color: t.tx3, marginBottom: 2 }}>{m.time}</span>}<div style={{ padding: "12px 16px", maxWidth: "88%", fontSize: 14, lineHeight: 1.65, whiteSpace: "pre-wrap", wordWrap: "break-word", borderRadius: u ? "16px 16px 4px 16px" : "16px 16px 16px 4px", background: u ? t.ub : t.ab, color: u ? t.ut : t.at, border: u ? "none" : "1px solid " + t.bdr }}>{m.text}</div></div>;
}

function ChatIn({ onSend, ld, ph, t }) {
  const [v, setV] = useState("");
  const go = () => { if (!v.trim() || ld) return; onSend(v.trim()); setV(""); };
  return <div style={{ display: "flex", gap: 8, padding: "12px 16px", borderTop: "1px solid " + t.bdr, background: t.bg }}><input value={v} onChange={e => setV(e.target.value)} onKeyDown={e => e.key === "Enter" && go()} placeholder={ph} style={{ flex: 1, padding: "12px 14px", border: "1.5px solid " + t.bdr, borderRadius: 12, fontSize: 14, fontFamily: "inherit", color: t.tx, background: t.ibg }} /><button onClick={go} disabled={ld || !v.trim()} style={{ padding: "12px 20px", background: "linear-gradient(135deg," + t.ac + "," + t.ac2 + ")", border: "none", borderRadius: 12, color: "#fff", fontSize: 14, fontWeight: 700, fontFamily: "inherit", opacity: (ld || !v.trim()) ? 0.5 : 1, cursor: "pointer" }}>{ld ? "..." : "Send"}</button></div>;
}

function ChatV({ msgs, ld, t, children }) {
  const end = useRef(null);
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, ld]);
  return <div style={{ flex: 1, overflowY: "auto", padding: 16, display: "flex", flexDirection: "column", gap: 12, background: t.cbg }}>{msgs.map((m, i) => <Bub key={i} m={m} t={t} />)}{ld && <Dots t={t} />}{children}<div ref={end} /></div>;
}

function DL({ c, fn, lb, t }) {
  return <a href={"data:text/html;charset=utf-8," + encodeURIComponent(c)} download={fn} style={{ padding: "6px 14px", border: "1.5px solid " + t.bdr, borderRadius: 20, background: t.card, color: t.tx2, fontSize: 13, fontFamily: "inherit", fontWeight: 600, textDecoration: "none" }}>{lb}</a>;
}

/* ── Sidebar ── */
function Sidebar({ chats, cur, onPick, onNew, onDel, onRen, t, onClose }) {
  const [ed, setEd] = useState(null); const [ev, setEv] = useState("");
  return <div style={{ width: 240, background: t.sb, borderRight: "1px solid " + t.bdr, display: "flex", flexDirection: "column", flexShrink: 0, height: "100%" }}>
    <div style={{ padding: "12px", borderBottom: "1px solid " + t.bdr, display: "flex", justifyContent: "space-between", alignItems: "center" }}><span style={{ fontWeight: 700, fontSize: 14, color: t.tx }}>Chats</span><div style={{ display: "flex", gap: 4 }}><button onClick={onNew} style={{ padding: "5px 10px", background: t.ac, border: "none", borderRadius: 8, color: "#fff", fontSize: 11, fontWeight: 700, fontFamily: "inherit", cursor: "pointer" }}>+ New</button><button onClick={onClose} style={{ border: "none", background: "transparent", fontSize: 14, color: t.tx3, cursor: "pointer" }}>✕</button></div></div>
    <div style={{ flex: 1, overflowY: "auto", padding: 6 }}>{chats.map(ch => <div key={ch.id} onClick={() => onPick(ch.id)} style={{ padding: "8px 10px", borderRadius: 8, background: cur === ch.id ? t.abg : "transparent", cursor: "pointer", marginBottom: 2, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
      {ed === ch.id ? <input value={ev} onChange={e => setEv(e.target.value)} onBlur={() => { onRen(ch.id, ev); setEd(null); }} onKeyDown={e => { if (e.key === "Enter") { onRen(ch.id, ev); setEd(null); } }} autoFocus style={{ flex: 1, padding: "3px 6px", border: "1px solid " + t.bdr, borderRadius: 4, fontSize: 12, fontFamily: "inherit", color: t.tx, background: t.ibg }} /> : <>
        <div style={{ flex: 1, overflow: "hidden" }}><div style={{ fontSize: 12, fontWeight: cur === ch.id ? 700 : 500, color: cur === ch.id ? t.ac : t.tx, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{ch.name}</div><div style={{ fontSize: 9, color: t.tx3 }}>{ch.date}</div></div>
        <div style={{ display: "flex", gap: 2, flexShrink: 0 }}><button onClick={e => { e.stopPropagation(); setEd(ch.id); setEv(ch.name); }} style={{ border: "none", background: "transparent", fontSize: 10, cursor: "pointer", padding: 2 }}>✏️</button><button onClick={e => { e.stopPropagation(); onDel(ch.id); }} style={{ border: "none", background: "transparent", fontSize: 10, cursor: "pointer", padding: 2 }}>🗑</button></div>
      </>}</div>)}{chats.length === 0 && <div style={{ padding: 12, textAlign: "center", fontSize: 12, color: t.tx3 }}>No chats yet</div>}</div>
  </div>;
}

/* ── Chat Manager Hook ── */
function useChatMgr(tabId) {
  const [chats, setChats] = useState([]);
  const [curId, setCurId] = useState(null);
  const [msgs, setMsgs] = useState([{ role: "ai", text: GREET[tabId] || "Hi!", time: TN() }]);
  const [ld, setLd] = useState(false);

  const add = m => { setMsgs(p => [...p, m]); if (curId) setChats(p => p.map(c => c.id === curId ? { ...c, msgs: [...c.msgs, m] } : c)); };
  const newChat = () => { const id = "c" + Date.now(); const m = [{ role: "ai", text: GREET[tabId] || "Hi!", time: TN() }]; setChats(p => [{ id, name: "New Chat", date: new Date().toLocaleDateString(), msgs: m }, ...p]); setCurId(id); setMsgs(m); };
  const pick = id => { const ch = chats.find(c => c.id === id); if (ch) { setCurId(id); setMsgs(ch.msgs); } };
  const del = id => { const rest = chats.filter(c => c.id !== id); setChats(rest); if (curId === id) { if (rest.length) pick(rest[0].id); else { setCurId(null); setMsgs([{ role: "ai", text: GREET[tabId] || "Hi!", time: TN() }]); } } };
  const ren = (id, name) => { if (name?.trim()) setChats(p => p.map(c => c.id === id ? { ...c, name } : c)); };

  useEffect(() => { if (chats.length === 0) newChat(); }, []);

  return { chats, curId, msgs, ld, setLd, add, newChat, pick, del, ren };
}

/* ═══ FLASHCARDS ═══ */
function FlashTab({ gate, t, cm }) {
  const { msgs, ld, setLd, add } = cm;
  const [cards, setCards] = useState([]); const [fl, setFl] = useState({}); const [idx, setIdx] = useState(0);

  const send = async text => {
    add({ role: "user", text, time: TN() });
    const has = cards.length > 0;
    const edit = has && isG(text, ["edit", "change", "add", "remove", "harder", "easier", "more", "fix"]);
    if (edit) {
      if (!(await gate())) return; setLd(true);
      try { const r = await ask("Edit flashcards. ONLY JSON:[{\"front\":\"...\",\"back\":\"...\"}]", "Cards:" + JSON.stringify(cards) + "\nEdit:" + text, 1024); const p = JSON.parse(r.replace(/```json|```/g, "").trim()); setCards(p); setFl({}); setIdx(0); add({ role: "ai", text: "Updated! ✏️ " + p.length + " cards.", time: TN() }); } catch { add({ role: "ai", text: "Error 🔄", time: TN() }); }
      setLd(false);
    } else if (text.length > 50 || isG(text, ["make", "create", "flashcard", "notes"])) {
      if (!(await gate())) return; setLd(true);
      try { const r = await ask("Create 6-8 flashcards. ONLY JSON:[{\"front\":\"...\",\"back\":\"...\"}]", text, 1024); const p = JSON.parse(r.replace(/```json|```/g, "").trim()); setCards(p); setFl({}); setIdx(0); add({ role: "ai", text: "✨ " + p.length + " cards!", time: TN() }); } catch { add({ role: "ai", text: "Error 🔄", time: TN() }); }
      setLd(false);
    } else { setLd(true); try { add({ role: "ai", text: await ask("PrepPal. Brief helpful.", text, 512), time: TN() }); } catch { add({ role: "ai", text: "🔄", time: TN() }); } setLd(false); }
  };

  const html = cards.length ? "<!DOCTYPE html><html><head><style>body{font-family:sans-serif;padding:20px}.g{display:grid;grid-template-columns:1fr 1fr;gap:12px}.c{border:2px solid #ddd;border-radius:10px;padding:16px}.l{font-size:9px;text-transform:uppercase;letter-spacing:1px;color:#999;margin-bottom:6px;font-weight:700}</style></head><body><h1>Flashcards</h1><div class=g>" + cards.map((c, i) => "<div class=c><div class=l>Q" + (i + 1) + "</div>" + c.front + "</div><div class=c><div class=l>A" + (i + 1) + "</div>" + c.back + "</div>").join("") + "</div></body></html>" : "";

  return <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
    <ChatV msgs={msgs} ld={ld} t={t}>
      {cards.length > 0 && <div style={{ display: "flex", flexDirection: "column", gap: 12, padding: "8px 0" }}>
        <div style={{ display: "flex", gap: 6, justifyContent: "center" }}><button onClick={() => { setCards([...cards].sort(() => Math.random() - 0.5)); setFl({}); setIdx(0); }} style={pil(t)}>🔀 Shuffle</button><DL c={html} fn="Flashcards.html" lb="⬇️ Download" t={t} /></div>
        <div onClick={() => setFl(p => ({ ...p, [idx]: !p[idx] }))} style={{ background: t.card, border: "1.5px solid " + t.bdr, borderRadius: 18, padding: "28px 20px 16px", cursor: "pointer", minHeight: 180, display: "flex", flexDirection: "column" }}>
          <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.5, color: t.ac, textTransform: "uppercase" }}>{fl[idx] ? "ANSWER" : "QUESTION"}</span>
          <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center", fontSize: 16, lineHeight: 1.6, color: t.tx, marginTop: 16 }}>{fl[idx] ? cards[idx]?.back : cards[idx]?.front}</div>
          <div style={{ fontSize: 11, color: t.tx3, textAlign: "center", marginTop: 10, fontStyle: "italic" }}>tap to flip</div>
        </div>
        <div style={{ display: "flex", gap: 14, justifyContent: "center", alignItems: "center" }}>
          <button onClick={() => setIdx(p => Math.max(0, p - 1))} disabled={idx === 0} style={{ width: 38, height: 38, borderRadius: "50%", border: "1.5px solid " + t.bdr, background: t.card, color: t.tx2, fontSize: 18, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>‹</button>
          <span style={{ fontSize: 13, color: t.tx3 }}>{(idx + 1) + "/" + cards.length}</span>
          <button onClick={() => setIdx(p => Math.min(cards.length - 1, p + 1))} disabled={idx === cards.length - 1} style={{ width: 38, height: 38, borderRadius: "50%", border: "1.5px solid " + t.bdr, background: t.card, color: t.tx2, fontSize: 18, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>›</button>
        </div>
      </div>}
    </ChatV>
    <ChatIn onSend={send} ld={ld} ph="Paste notes or chat..." t={t} />
  </div>;
}

/* ═══ QUIZ ═══ */
function QuizTab({ gate, t, cm }) {
  const { msgs, ld, setLd, add } = cm;
  const [quiz, setQuiz] = useState(null); const [ans, setAns] = useState({}); const [done, setDone] = useState(false);

  const send = async text => {
    add({ role: "user", text, time: TN() });
    if (isG(text, ["quiz", "test", "make", "create", "question"]) || text.length > 80) {
      if (!(await gate())) return; setLd(true); setQuiz(null); setAns({}); setDone(false);
      const nm = text.match(/(\d+)\s*q/i); const nq = nm ? Math.min(parseInt(nm[1]), 20) : 5;
      try { const r = await ask("Create " + nq + " MCQs. ONLY JSON:[{\"question\":\"...\",\"options\":[\"A\",\"B\",\"C\",\"D\"],\"correct\":0,\"explanation\":\"...\"}]", text, Math.min(4096, nq * 200)); const p = JSON.parse(r.replace(/```json|```/g, "").trim()); if (Array.isArray(p) && p.length) { setQuiz(p); add({ role: "ai", text: p.length + " questions! 📝", time: TN() }); } else add({ role: "ai", text: "Couldn't 🤔", time: TN() }); } catch { add({ role: "ai", text: "Error 🔄", time: TN() }); }
      setLd(false);
    } else { setLd(true); try { add({ role: "ai", text: await ask("PrepPal. Brief.", text, 512), time: TN() }); } catch { add({ role: "ai", text: "🔄", time: TN() }); } setLd(false); }
  };
  const sub = () => { setDone(true); let s = 0; quiz.forEach((q, i) => { if (ans[i] === q.correct) s++; }); add({ role: "ai", text: s + "/" + quiz.length + " " + (s === quiz.length ? "Perfect! 🏆" : s >= quiz.length * 0.7 ? "Great! 💪" : "Keep studying! 📖"), time: TN() }); };

  return <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
    <ChatV msgs={msgs} ld={ld} t={t}>
      {quiz && <div style={{ display: "flex", flexDirection: "column", gap: 16, padding: "8px 0" }}>
        {quiz.map((q, qi) => <div key={qi} style={{ background: t.card, border: "1.5px solid " + t.bdr, borderRadius: 14, padding: 16, display: "flex", flexDirection: "column", gap: 8 }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: t.tx }}>{(qi + 1) + ". " + q.question}</div>
          {q.options.map((o, oi) => { let bg = t.ibg, bd = "1px solid " + t.bdr; const sel = ans[qi] === oi, cor = q.correct === oi; if (done && cor) { bg = "rgba(111,207,151,.15)"; bd = "1px solid #6fcf97"; } else if (done && sel && !cor) { bg = "rgba(235,87,87,.15)"; bd = "1px solid #eb5757"; } else if (sel) { bg = t.abg; bd = "1px solid " + t.ac; } return <button key={oi} onClick={() => !done && setAns(p => ({ ...p, [qi]: oi }))} style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 12px", borderRadius: 8, background: bg, border: bd, color: t.tx, fontSize: 13, fontFamily: "inherit", textAlign: "left", width: "100%", cursor: done ? "default" : "pointer" }}><span style={{ fontWeight: 700, color: t.ac, minWidth: 16 }}>{String.fromCharCode(65 + oi)}</span>{o}</button>; })}
          {done && q.explanation && <div style={{ padding: "8px 12px", background: t.abg, borderRadius: 8, fontSize: 12, color: t.tx2 }}>{"💡 " + q.explanation}</div>}
        </div>)}
        {!done && <button onClick={sub} disabled={Object.keys(ans).length < quiz.length} style={{ padding: "12px 20px", background: "linear-gradient(135deg," + t.ac + "," + t.ac2 + ")", border: "none", borderRadius: 12, color: "#fff", fontSize: 14, fontWeight: 700, fontFamily: "inherit", opacity: Object.keys(ans).length < quiz.length ? 0.5 : 1, cursor: "pointer" }}>✅ Submit</button>}
      </div>}
    </ChatV>
    <ChatIn onSend={send} ld={ld} ph="Paste notes..." t={t} />
  </div>;
}

/* ═══ SIMPLE TAB ═══ */
function SimpleTab({ gate, t, cm, sys, ph }) {
  const { msgs, ld, setLd, add } = cm;
  const send = async text => { add({ role: "user", text, time: TN() }); if (!(await gate())) return; setLd(true); try { add({ role: "ai", text: await ask(sys, text, 1024), time: TN() }); } catch { add({ role: "ai", text: "Error 🔄", time: TN() }); } setLd(false); };
  return <div style={{ display: "flex", flexDirection: "column", height: "100%" }}><ChatV msgs={msgs} ld={ld} t={t} /><ChatIn onSend={send} ld={ld} ph={ph} t={t} /></div>;
}

/* ═══ POSTER ═══ */
function PosterTab({ gate, t, cm }) {
  const { msgs, ld, setLd, add } = cm;
  const [html, setHtml] = useState("");
  const ds = x => { const l = x.toLowerCase(); if (l.includes("modern")) return "modern"; if (l.includes("creative") || l.includes("fun")) return "creative"; return "academic"; };
  const build = (title, secs, style) => { const C = { academic: { bg: "#1a2744", tx: "#fff", sc: "#f7fafc", bd: "#cbd5e0", fn: "Georgia,serif" }, modern: { bg: "#6c63ff", tx: "#fff", sc: "#f5f3ff", bd: "#ddd6fe", fn: "Helvetica,sans-serif" }, creative: { bg: "#e84393", tx: "#fff", sc: "#fff0f6", bd: "#f8a5c2", fn: "Trebuchet MS,sans-serif" } }; const c = C[style] || C.academic; return "<!DOCTYPE html><html><head><meta charset=utf-8></head><body style='margin:0;padding:40px;background:#fff;font-family:" + c.fn + "'><div style='max-width:1100px;margin:0 auto'><div style='background:" + c.bg + ";color:" + c.tx + ";padding:40px 48px;border-radius:12px;text-align:center;margin-bottom:32px'><h1 style='margin:0;font-size:42px;font-weight:800'>" + title + "</h1></div><div style='column-count:2;column-gap:28px'>" + secs.map(s => { const p = s.split("\n").filter(x => x.trim()); return "<div style='background:" + c.sc + ";border:1px solid " + c.bd + ";border-radius:8px;padding:24px;break-inside:avoid;margin-bottom:20px'><h2 style='margin:0 0 12px;font-size:22px;color:" + c.bg + "'>" + (p[0] || "") + "</h2><p style='margin:0;font-size:15px;line-height:1.7'>" + p.slice(1).join(" ") + "</p></div>"; }).join("") + "</div></div></body></html>"; };

  const send = async text => {
    add({ role: "user", text, time: TN() }); if (!(await gate())) return;
    setLd(true); const style = ds(text);
    const topic = text.replace(/poster|make|create|about|me|a|the/gi, "").trim() || text;
    let raw = null;
    try { raw = await Promise.race([ask("Write short poster.\nTITLE: title\n---\nHeading\nSentence.\n---\nHeading\nSentence.\n3 sections.", text, 400), new Promise((_, j) => setTimeout(j, 12000))]); }
    catch { raw = "TITLE: " + topic.charAt(0).toUpperCase() + topic.slice(1) + "\n---\nOverview\nAbout " + topic + ".\n---\nDetails\nKey facts about " + topic + ".\n---\nSummary\nMain points."; add({ role: "ai", text: "AI slow — starter made. Tell me edits! 🎨", time: TN() }); }
    const parts = raw.split("---").map(s => s.trim()).filter(Boolean);
    let title = text, secs = parts;
    if (parts[0] && parts[0].toUpperCase().startsWith("TITLE:")) { title = parts[0].replace(/^TITLE:\s*/i, "").trim(); secs = parts.slice(1); }
    if (!secs.length) secs = ["Content\nAbout " + text];
    setHtml(build(title, secs, style));
    if (!raw.includes("starter")) add({ role: "ai", text: "Your " + style + " poster! 🎉", time: TN() });
    setLd(false);
  };

  return <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
    <ChatV msgs={msgs} ld={ld} t={t}>
      {html && <div style={{ display: "flex", flexDirection: "column", gap: 8, padding: "8px 0" }}>
        <div style={{ display: "flex", justifyContent: "flex-end" }}><DL c={html} fn="Poster.html" lb="⬇️ Download" t={t} /></div>
        <div style={{ borderRadius: 14, overflow: "hidden", border: "1.5px solid " + t.bdr, background: "#fff" }}><iframe srcDoc={html} style={{ width: "100%", height: 380, border: "none" }} title="P" sandbox="allow-same-origin" /></div>
      </div>}
    </ChatV>
    <ChatIn onSend={send} ld={ld} ph="Poster topic..." t={t} />
  </div>;
}

/* ═══ TIMER ═══ */
function TimerTab({ t }) {
  const [m, setM] = useState(25); const [s, setS] = useState(0); const [run, setRun] = useState(false);
  const [mode, setMode] = useState("focus"); const [fin, setFin] = useState(false); const ref = useRef();
  const rst = md => { clearInterval(ref.current); setRun(false); setFin(false); setMode(md); setM(md === "focus" ? 25 : md === "short" ? 5 : 15); setS(0); };
  useEffect(() => { if (!run) return; ref.current = setInterval(() => { setS(s => { if (s === 0) { setM(m => { if (m === 0) { clearInterval(ref.current); setRun(false); setFin(true); playAlarm(); return 0; } return m - 1; }); return 59; } return s - 1; }); }, 1000); return () => clearInterval(ref.current); }, [run]);
  const tot = mode === "focus" ? 1500 : mode === "short" ? 300 : 900; const pct = (tot - (m * 60 + s)) / tot; const cv = 2 * Math.PI * 88;
  return <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 24, padding: 24 }}>
    <div style={{ display: "flex", gap: 6 }}>{[["focus", "🎯 Focus"], ["short", "☕ Break"], ["long", "🌿 Long"]].map(([md, l]) => <button key={md} onClick={() => rst(md)} style={{ ...pil(t), ...(mode === md ? { background: t.abg, borderColor: t.ac, color: t.ac, fontWeight: 700 } : {}) }}>{l}</button>)}</div>
    <div style={{ position: "relative", width: 210, height: 210 }}><svg width="210" height="210" viewBox="0 0 210 210"><circle cx="105" cy="105" r="88" fill="none" stroke={t.bdr} strokeWidth="6" /><circle cx="105" cy="105" r="88" fill="none" stroke={fin ? "#6fcf97" : t.ac} strokeWidth="6" strokeLinecap="round" strokeDasharray={cv} strokeDashoffset={cv * (1 - pct)} transform="rotate(-90 105 105)" style={{ transition: "stroke-dashoffset .5s" }} /></svg><div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}><span style={{ fontSize: 44, fontWeight: 600, color: t.tx, letterSpacing: 2 }}>{String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0")}</span><span style={{ fontSize: 11, color: fin ? "#6fcf97" : t.tx3 }}>{fin ? "Time's up!" : mode === "focus" ? "stay focused" : "relax"}</span></div></div>
    <div style={{ display: "flex", gap: 10 }}><button onClick={() => { setFin(false); setRun(!run); }} style={{ padding: "12px 24px", background: "linear-gradient(135deg," + t.ac + "," + t.ac2 + ")", border: "none", borderRadius: 12, color: "#fff", fontSize: 15, fontWeight: 700, fontFamily: "inherit", cursor: "pointer" }}>{run ? "⏸ Pause" : "▶ Start"}</button><button onClick={() => rst(mode)} style={{ padding: "12px 24px", background: "transparent", border: "1.5px solid " + t.bdr, borderRadius: 12, color: t.tx2, fontSize: 15, fontWeight: 600, fontFamily: "inherit", cursor: "pointer" }}>↺ Reset</button></div>
  </div>;
}

/* ═══ AUTH ═══ */
function AuthScreen({ onEnter, t }) {
  const [mode, setMode] = useState("login");
  const [name, setName] = useState(""); const [email, setEmail] = useState(""); const [pw, setPw] = useState(""); const [pw2, setPw2] = useState("");
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const go = async () => {
    setErr(""); const em = email.trim().toLowerCase();
    if (!em) return setErr("Enter email."); if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(em)) return setErr("Valid email needed.");
    if (!pw || pw.length < 6) return setErr("Password: 6+ chars.");
    if (mode === "signup") { if (!name.trim()) return setErr("Enter name."); if (pw !== pw2) return setErr("Passwords don't match."); }
    setBusy(true);
    const users = sGet("pp_u") || {};
    const isPro = PRO.includes(em);
    if (mode === "signup") {
      if (users[em]) { setBusy(false); return setErr("Account exists."); }
      const u = { name: name.trim(), email: em, password: pw, isPro, usesLeft: isPro ? 999 : 3 };
      users[em] = u; sSet("pp_u", users); sSet("pp_s", u); setBusy(false); onEnter(u);
    } else {
      const u = users[em]; if (!u) { setBusy(false); return setErr("No account."); } if (u.password !== pw) { setBusy(false); return setErr("Wrong password."); }
      if (isPro && !u.isPro) { u.isPro = true; u.usesLeft = 999; users[em] = u; sSet("pp_u", users); }
      sSet("pp_s", u); setBusy(false); onEnter(u);
    }
  };
  const inp = { width: "100%", padding: "13px 15px", border: "1.5px solid " + t.bdr, borderRadius: 12, fontSize: 15, fontFamily: "inherit", color: t.tx, background: t.ibg };
  return <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: t.bg, fontFamily: "'DM Sans',sans-serif", padding: 20 }}>
    <div style={{ width: "100%", maxWidth: 380, background: t.card, borderRadius: 24, padding: "36px 28px", boxShadow: "0 4px 40px rgba(0,0,0,.08)", display: "flex", flexDirection: "column", alignItems: "center", gap: 14 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}><div style={{ width: 44, height: 44, borderRadius: 12, background: "linear-gradient(135deg," + t.ac + "," + t.ac2 + ")", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 22, color: "#fff" }}>P</div><span style={{ fontWeight: 800, fontSize: 26, color: t.tx }}>PrepPal</span></div>
      <p style={{ fontSize: 13, color: t.tx2, textAlign: "center", margin: 0 }}>Your study prep pal</p>
      <div style={{ display: "flex", background: t.cbg, borderRadius: 12, padding: 4, width: "100%" }}>
        <button onClick={() => { setMode("login"); setErr(""); }} style={{ flex: 1, padding: "10px 0", border: "none", borderRadius: 10, background: mode === "login" ? t.card : "transparent", color: mode === "login" ? t.tx : t.tx2, fontFamily: "inherit", fontSize: 14, fontWeight: mode === "login" ? 700 : 500, cursor: "pointer" }}>Sign In</button>
        <button onClick={() => { setMode("signup"); setErr(""); }} style={{ flex: 1, padding: "10px 0", border: "none", borderRadius: 10, background: mode === "signup" ? t.card : "transparent", color: mode === "signup" ? t.tx : t.tx2, fontFamily: "inherit", fontSize: 14, fontWeight: mode === "signup" ? 700 : 500, cursor: "pointer" }}>Sign Up</button>
      </div>
      {mode === "signup" && <input value={name} onChange={e => setName(e.target.value)} placeholder="Full name" style={inp} />}
      <input value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" type="email" style={inp} />
      <input value={pw} onChange={e => setPw(e.target.value)} placeholder="Password" type="password" style={inp} onKeyDown={e => e.key === "Enter" && mode === "login" && go()} />
      {mode === "signup" && <input value={pw2} onChange={e => setPw2(e.target.value)} placeholder="Confirm password" type="password" style={inp} onKeyDown={e => e.key === "Enter" && go()} />}
      {err && <div style={{ width: "100%", padding: "9px 13px", borderRadius: 10, background: "rgba(235,87,87,.1)", color: "#eb5757", fontSize: 13 }}>{err}</div>}
      <button onClick={go} disabled={busy} style={{ width: "100%", padding: 14, background: "linear-gradient(135deg," + t.ac + "," + t.ac2 + ")", border: "none", borderRadius: 14, color: "#fff", fontSize: 16, fontWeight: 700, fontFamily: "inherit", cursor: busy ? "wait" : "pointer", opacity: busy ? 0.7 : 1 }}>{busy ? "..." : mode === "login" ? "Sign In →" : "Create Account →"}</button>
    </div>
  </div>;
}

/* ═══ MAIN APP ═══ */
export default function PrepPal() {
  const [user, setUser] = useState(null); const [tab, setTab] = useState("flash"); const [pw, setPw] = useState(false); const [dark, setDark] = useState(false); const [sb, setSb] = useState(false);
  const t = dark ? DK : LT;
  const flashCm = useChatMgr("flash"); const quizCm = useChatMgr("quiz"); const sumCm = useChatMgr("sum"); const hwCm = useChatMgr("hw"); const posterCm = useChatMgr("poster");
  const cms = { flash: flashCm, quiz: quizCm, sum: sumCm, hw: hwCm, poster: posterCm };
  const cm = cms[tab];

  useEffect(() => { const s = sGet("pp_s"); if (s?.email) { const isPro = PRO.includes(s.email); setUser({ ...s, isPro: isPro || s.isPro, usesLeft: (isPro || s.isPro) ? 999 : (s.usesLeft ?? 3) }); } const d = sGet("pp_dk"); if (d) setDark(true); }, []);

  const enter = u => { setUser(u); sSet("pp_s", u); };
  const gate = useCallback(async () => { if (user.isPro) return true; if (user.usesLeft > 0) { const up = { ...user, usesLeft: user.usesLeft - 1 }; setUser(up); sSet("pp_s", up); return true; } setPw(true); return false; }, [user]);

  if (!user) return <AuthScreen onEnter={enter} t={t} />;

  return <div style={{ height: "100vh", display: "flex", background: t.bg, fontFamily: "'DM Sans',sans-serif", color: t.tx }}>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
    <style>{`@keyframes fu{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}@keyframes dp{0%,100%{opacity:.3;transform:scale(.8)}50%{opacity:1;transform:scale(1.1)}}*{box-sizing:border-box}input:focus{outline:none;border-color:${t.ac}!important}button{transition:all .12s}button:disabled{opacity:.5;cursor:not-allowed}::-webkit-scrollbar{width:5px}::-webkit-scrollbar-thumb{background:rgba(155,125,255,.2);border-radius:3px}`}</style>

    {sb && tab !== "timer" && cm && <Sidebar chats={cm.chats} cur={cm.curId} onPick={cm.pick} onNew={cm.newChat} onDel={cm.del} onRen={cm.ren} t={t} onClose={() => setSb(false)} />}

    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 16px", borderBottom: "1px solid " + t.bdr, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          {tab !== "timer" && <button onClick={() => setSb(!sb)} style={{ border: "none", background: "transparent", fontSize: 18, cursor: "pointer", color: t.tx2 }}>☰</button>}
          <div style={{ width: 30, height: 30, borderRadius: 8, background: "linear-gradient(135deg," + t.ac + "," + t.ac2 + ")", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 15, color: "#fff" }}>P</div>
          <span style={{ fontWeight: 800, fontSize: 17, color: t.tx }}>PrepPal</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button onClick={() => { setDark(!dark); sSet("pp_dk", !dark); }} style={{ border: "none", background: "transparent", fontSize: 16, cursor: "pointer" }}>{dark ? "☀️" : "🌙"}</button>
          {user.isPro ? <span style={{ fontSize: 10, padding: "3px 8px", background: "linear-gradient(135deg," + t.ac + "," + t.ac2 + ")", borderRadius: 20, color: "#fff", fontWeight: 700 }}>PRO</span> : <button onClick={() => setPw(true)} style={{ fontSize: 10, padding: "3px 8px", background: t.cbg, borderRadius: 20, color: t.tx2, fontWeight: 700, border: "1px solid " + t.bdr, fontFamily: "inherit", cursor: "pointer" }}>{user.usesLeft + " left"}</button>}
          <div style={{ width: 26, height: 26, borderRadius: "50%", background: t.cbg, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 11, color: t.tx2 }}>{(user.name || "?")[0].toUpperCase()}</div>
          <button onClick={() => { setUser(null); sSet("pp_s", null); }} style={{ border: "none", background: "transparent", color: t.tx3, fontSize: 11, fontFamily: "inherit", cursor: "pointer" }}>Out</button>
        </div>
      </div>
      <div style={{ display: "flex", gap: 2, padding: "8px 10px", overflowX: "auto", borderBottom: "1px solid " + t.bdr, flexShrink: 0 }}>
        {TABS.map(tb => <button key={tb.id} onClick={() => { setTab(tb.id); setSb(false); }} style={{ display: "flex", alignItems: "center", gap: 4, padding: "6px 10px", border: "none", borderRadius: 9, background: tab === tb.id ? t.abg : "transparent", color: tab === tb.id ? t.ac : t.tx3, fontFamily: "inherit", fontWeight: tab === tb.id ? 700 : 500, fontSize: 12, whiteSpace: "nowrap", cursor: "pointer" }}><span>{tb.i}</span><span>{tb.l}</span></button>)}
      </div>
      <div style={{ flex: 1, overflow: "hidden", display: "flex", flexDirection: "column" }}>
        {tab === "flash" && <FlashTab gate={gate} t={t} cm={flashCm} />}
        {tab === "quiz" && <QuizTab gate={gate} t={t} cm={quizCm} />}
        {tab === "sum" && <SimpleTab gate={gate} t={t} cm={sumCm} sys="Brilliant summarizer. Bullets with headers. Thorough." ph="Paste notes..." />}
        {tab === "hw" && <SimpleTab gate={gate} t={t} cm={hwCm} sys="Elite tutor. Math:ALL steps. Direct. Encouraging." ph="Ask anything..." />}
        {tab === "poster" && <PosterTab gate={gate} t={t} cm={posterCm} />}
        {tab === "timer" && <TimerTab t={t} />}
      </div>
    </div>

    {pw && <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 20 }} onClick={() => setPw(false)}><div style={{ width: "100%", maxWidth: 380, background: t.card, borderRadius: 24, padding: "32px 24px", display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", gap: 8, position: "relative" }} onClick={e => e.stopPropagation()}><button onClick={() => setPw(false)} style={{ position: "absolute", top: 12, right: 14, border: "none", background: "transparent", fontSize: 18, color: t.tx3, cursor: "pointer" }}>✕</button><div style={{ fontSize: 36 }}>🔓</div><h2 style={{ fontSize: 20, fontWeight: 800, color: t.tx, margin: 0 }}>Free tries used!</h2><div style={{ width: "100%", background: t.cbg, border: "1.5px solid " + t.bdr, borderRadius: 16, padding: 16, marginTop: 8 }}><div style={{ fontSize: 32, fontWeight: 800, color: t.ac }}>{PRICE}</div></div><a href={STRIPE + "?prefilled_email=" + encodeURIComponent(user.email)} target="_blank" rel="noopener noreferrer" onClick={() => { const up = { ...user, isPro: true, usesLeft: 999 }; setUser(up); sSet("pp_s", up); setPw(false); }} style={{ width: "100%", padding: 14, background: "#1a1a2e", border: "none", borderRadius: 14, color: "#fff", fontSize: 15, fontWeight: 700, fontFamily: "inherit", cursor: "pointer", marginTop: 8, textDecoration: "none", textAlign: "center", display: "block" }}>{"Subscribe — " + PRICE}</a></div></div>}
  </div>;
}
